<?php include("../model/class.expert1.php"); ?>
<?php
include('map_function_list.php');
include('PHPMailer-master/PHPMailerAutoload.php');
include('passwordHash.php');
if(($_REQUEST['ActionCall']=="AdminloginAccessCall"))
{
$ModelCall->where("client_email", $ModelCall->utf8_decode_all($_REQUEST['adminemail']));
$ModelCall->where("client_password", $ModelCall->utf8_decode_all($_REQUEST['password']));
$ModelCall->where("status",1);
$ModelCall->orderBy("id","asc");
$rec = $ModelCall->get("tbl_client_sub_account");
if($ModelCall->count==1)
{ 
$_SESSION['ADMIN_CLIENT_LOGINID']=$rec[0]['id'];
header("location:".DOMAIN.AdminDirectory."index.php?actionResult=loginsuccess");
}
else 
{
header("location:".DOMAIN.AdminDirectory."login.php?actionResult=loginerror");
}
}
?>
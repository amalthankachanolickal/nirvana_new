<?php 
session_start();
error_reporting(0);
require_once('MysqliDb.php');
$ModelCall = new MysqliDb ('localhost', 'innovzzy_Ncoln', 'Adminadmin!@123456', 'innovzzy__NCoIn');
 
define('DOMAIN','https://www.nirvanacountry.co.in/');
define('AdminDirectory','RWAVendor/');
define('includes','include/');
define('NOIMAGE','noimage.png');
define('DATE',date('d l Y'));
define('CURRENTDATE',date('Y-m-d'));
?>
